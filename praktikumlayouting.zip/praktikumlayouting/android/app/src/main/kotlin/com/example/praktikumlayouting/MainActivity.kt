package com.example.praktikumlayouting

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
